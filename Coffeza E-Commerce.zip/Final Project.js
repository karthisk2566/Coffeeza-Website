< img src = "//coffeeza.in/cdn/shop/files/3_6.webp?v=1769744994"
alt = "Classic Intensity Trio - Coffee Capsules - Variety Pack Of 3"
class = "product-image"
height = "100%"
width = "100%" >